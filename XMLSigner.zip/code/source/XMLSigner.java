

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import org.apache.wss4j.common.WSEncryptionPart;
import org.apache.wss4j.common.crypto.Crypto;
import org.apache.wss4j.common.crypto.CryptoFactory;
import org.apache.wss4j.common.ext.WSSecurityException;
import org.apache.wss4j.dom.WSConstants;
import org.apache.wss4j.dom.message.WSSecHeader;
import org.apache.wss4j.dom.message.WSSecSignature;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.Security;
import java.util.Properties;
import org.xml.sax.InputSource;
import java.io.StringReader;
import javax.xml.transform.OutputKeys;
import java.io.StringWriter;
// --- <<IS-END-IMPORTS>> ---

public final class XMLSigner

{
	// ---( internal utility methods )---

	final static XMLSigner _instance = new XMLSigner();

	static XMLSigner _newInstance() { return new XMLSigner(); }

	static XMLSigner _cast(Object o) { return (XMLSigner)o; }

	// ---( server methods )---




	public static final void XMLSigner (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(XMLSigner)>> ---
		// @sigtype java 3.5
		// [i] field:0:required xmlToSign
		// [i] field:0:required keyStoreFilePath
		// [i] field:0:required keyStorePassword
		// [i] field:0:required aliasName
		// [i] field:0:required aliasPassword
		// [o] field:0:required signedXml
		// --- Read Input ---
		    IDataCursor pipelineCursor = pipeline.getCursor();
		    String xmlToSign = IDataUtil.getString(pipelineCursor, "xmlToSign");
		    String keyStoreFilePath = IDataUtil.getString(pipelineCursor, "keyStoreFilePath");
		    String keyStorePassword = IDataUtil.getString(pipelineCursor, "keyStorePassword");
		    String aliasName = IDataUtil.getString(pipelineCursor, "aliasName");
		    String aliasPassword = IDataUtil.getString(pipelineCursor, "aliasPassword");
		    
		   
		    try {
		        String signedXml = signSoapXmlFile(xmlToSign, keyStoreFilePath, keyStorePassword, aliasName, aliasPassword);
		        IDataUtil.put(pipelineCursor, "signedXml", signedXml);
		        
		    } catch (Exception e) {
		        System.err.println("Error signing XML: " + e.getMessage());
		        e.printStackTrace();
		    }finally {
		    	if(pipelineCursor != null){
		    		pipelineCursor.destroy();
		    	}
			}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static final String SOAP_ENVELOPE_NAMESPACE = "http://schemas.xmlsoap.org/soap/envelope/";
	
	static {
	    org.apache.xml.security.Init.init();
	    if (Security.getProvider("BC") == null) {
	        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	    }
	}
	
	 public static String signSoapXmlFile(String xmlToSign, String keyStoreFilePath, String keyStorePassword,
	            String aliasName, String aliasPassword) throws Exception {
	
	        // 1. Load the XML document
	        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	        dbf.setNamespaceAware(true);
	        DocumentBuilder db = dbf.newDocumentBuilder();
	        Document doc = db.parse(new InputSource(new StringReader(xmlToSign)));
	
	        // 2. Configure Crypto (Keystore properties)
	        Properties cryptoProperties = new Properties();
	        cryptoProperties.put("org.apache.wss4j.crypto.provider", "org.apache.wss4j.common.crypto.Merlin");
	        cryptoProperties.put("org.apache.wss4j.crypto.merlin.keystore.type", "PKCS12");
	        cryptoProperties.put("org.apache.wss4j.crypto.merlin.keystore.file", keyStoreFilePath);
	        cryptoProperties.put("org.apache.wss4j.crypto.merlin.keystore.password", keyStorePassword);
	        cryptoProperties.put("org.apache.wss4j.crypto.merlin.keystore.private.password", aliasPassword);
	
	        Crypto crypto = CryptoFactory.getInstance(cryptoProperties);
	
	        // 3. Create WS-Security Header
	        WSSecHeader secHeader = new WSSecHeader(doc);
	        secHeader.insertSecurityHeader();
	
	        // 4. Create WSSecSignature object
	        WSSecSignature wsSign = new WSSecSignature(secHeader);
	
	        // --- IMPORTANT: Tell WSSecSignature which key to use via its alias and password ---
	        wsSign.setUserInfo(aliasName, aliasPassword);
	
	        /*
	         * `setKeyIdentifierType()` is used to specify how the signing key (typically a public key or certificate)
	         *  will be referenced within the <KeyInfo> element of a SOAP message's XML Digital Signature.
	         *  the default or recommended option for signing is often WSConstants.ISSUER_SERIAL
	         * */
	        //wsSign.setKeyIdentifierType(WSConstants.BST_DIRECT_REFERENCE);
	        wsSign.setSignatureAlgorithm(WSConstants.RSA_SHA1);
	        wsSign.setDigestAlgo(WSConstants.SHA1);
	        wsSign.setSigCanonicalization(WSConstants.C14N_EXCL_OMIT_COMMENTS);
	
	        NodeList bodyList = doc.getElementsByTagNameNS(SOAP_ENVELOPE_NAMESPACE, WSConstants.ELEM_BODY);
	        if (bodyList.getLength() == 0) {
	            throw new WSSecurityException(WSSecurityException.ErrorCode.INVALID_SECURITY,
	                    "No SOAP Body found in the document.");
	        }
	        Element soapBody = (Element) bodyList.item(0);
	
	        String bodyId = soapBody.getAttributeNS(WSConstants.WSU_NS, "Id");
	        if (bodyId == null || bodyId.isEmpty()) {
	            bodyId = "id-" + System.nanoTime();
	            soapBody.setAttributeNS(WSConstants.WSU_NS, "wsu:Id", bodyId);
	            soapBody.setIdAttributeNS(WSConstants.WSU_NS, "Id", true);
	        }
	
	        // Correct WSEncryptionPart instantiation for signing by ID
	        wsSign.getParts().add(
	                new WSEncryptionPart(
	                        bodyId, // The actual ID of the element (e.g., "\u0647\u064A-12345")
	                        "Element" // To sign the entire element (not just its content)
	                ));
	
	        /* 
	         * wsSign.build(crypto) will now use the userInfo (alias, password) and the
	         * crypto object to find the private key and certificate itself.
	         */
	        Document signedDoc = wsSign.build(crypto);
	    	// 7. convert Document to string and return
	        return convertDocumentToString(signedDoc);
	    }
	 
	 	public static String convertDocumentToString(Document doc) throws Exception {
	        TransformerFactory tf = TransformerFactory.newInstance();
	        Transformer transformer = tf.newTransformer();
	        transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");//new
	        //transformer.setOutputProperty(OutputKeys.INDENT, "yes");//new
	        // Convert Document to String
	        StringWriter writer = new StringWriter();
	        transformer.transform(new DOMSource(doc), new StreamResult(writer));
	        return writer.getBuffer().toString();
	    }
	// --- <<IS-END-SHARED>> ---
}

